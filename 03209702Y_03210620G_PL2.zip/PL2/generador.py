import csv
import random


def prep_csv(csv_file):
    with open(csv_file, 'r+') as fd:
        lines = fd.readlines()
        fd.seek(0)
        fd.writelines(line for line in lines if line.strip())
        fd.truncate()

#list of 50 countries in python
countries = ['Spain', 'Albania', 'Algeria', 'Andorra', 'Angola', 'Antigua and Barbuda', 'Argentina', 'Armenia', \
    'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus', 'Belgium', \
        'Belize', 'Benin', 'Bhutan', 'Bolivia', 'Bosnia and Herzegovina','Botswana', 'Brazil', 'Brunei', 'Bulgaria', \
            'Burkina Faso', 'Burundi', 'Cambodia', 'Cameroon', 'Canada', 'Cape Verde', 'Central African Republic', 'Chad', \
                'Chile', 'China', 'Colombia', 'Comoros', 'Congo (Brazzaville)', 'Congo', 'Costa Rica', 'Cote d\'Ivoire', \
                    'Croatia', 'Cuba', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 'Dominica', 'Dominican Republic', \
                        'East Timor (Timor Timur)', 'Ecuador', 'Egypt', 'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia',\
                             'Ethiopia', 'Fiji', 'Finland', 'France', 'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana', 'Greece', \
                                 'Grenada', 'Guatemala', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Honduras', 'Hungary', \
                                     'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland']


file = open('universidades.csv', 'w', newline='')
lista = [[]]
codigos_universidad = []
asignaturas_universidades = {} #diccionario con las asignaturas de cada universidad identificada por su codigo
writer = csv.writer(file, delimiter=';')
for i in range(100000): 
    fila = []
    #codigo_erasmus
    fila.insert(0, repr(i))
    codigos_universidad.append(repr(i))
    asignaturas_universidades.update({repr(i) : []})
    #nombre
    fila.insert(1, "universidad"+repr(i))
    #direccion
    fila.insert(2, "direccion"+repr(i))
    #pais
    fila.insert(3, random.choice(countries))
    #telefono
    fila.insert(4, repr(random.randint(1, 999999999)).zfill(9))
    #email
    fila.insert(5, "email"+repr(i))
    lista.insert(i, fila)

writer.writerows(lista)
file.close()
prep_csv('universidades.csv')
print("Universidades Generadas")


file = open('estudiantes.csv', 'w', newline='')
lista = [[]]

writer = csv.writer(file, delimiter=';')
for i in range(5000000):
    fila = []
    #codigo_estudiantes
    fila.append(repr(i))
    #nombre
    fila.insert(1, "nombre"+repr(i))
    #apellidos
    fila.insert(2, "apellidos"+repr(i))
    #direccion
    fila.insert(3, "direccion"+repr(i))
    #pais
    fila.insert(4, random.choice(countries))
    #telefono
    fila.insert(5, repr(random.randint(1, 999999999)).zfill(9))
    #email
    fila.insert(6, "email"+repr(i))
    #creditos_aprobados
    fila.insert(7, repr(random.randint(60, 200)))
    #codigo_erasmus_universidades
    fila.insert(8, random.choice(codigos_universidad))
    
    lista.insert(i, fila)
writer.writerows(lista)
file.close()
prep_csv('estudiantes.csv')
print("Estudiantes generados")

file = open('asignaturas.csv', 'w', newline='')
writer = csv.writer(file, delimiter=';')
lista_asignaturas = [[]]
tipo = ['basica', 'obligatoria', 'transversal','optativa']
for i in range(100000):    
    for j in range(random.randint(15,20)):
        fila = []
        #codigo_asignatura
        fila.insert(0, repr(len(lista_asignaturas)))
        #nombre
        fila.insert(1, "asignatura"+repr(len(lista_asignaturas)))
        #creditos
        fila.insert(2, random.randint(4, 12))
        #tipo
        fila.insert(3, tipo[random.randint(0, len(tipo)-1)])
        #universidad
        fila.insert(4, i)

        asignaturas_universidades[repr(i)].append(fila)
        lista_asignaturas.append(fila)
writer.writerows(lista_asignaturas)
file.close()
prep_csv('asignaturas.csv')
print("Asignaturas generadas")


file = open('estancias.csv', 'w', newline='')
lista = [[]]
estancias = {}
tipoBeca = ['KA103', 'KA107', 'MIT', 'Franklin', 'SICUE', 'Global']
duraciones = ['1','2','A']
writer = csv.writer(file, delimiter=';')
for i in range(5000000):
    fila = []
    duracion =  duraciones[random.randint(0, len(duraciones)-1)]
    estancias.update({repr(i) : duracion})
    meses = ['09','10','11','12','01','02','03','04','05','06']
    
    if duracion == '1' or duracion == 'A': 
        mes_ini = meses[0] #inicio en enero
        mes_fin = meses[4] #fin en enero
        dia_ini = repr(random.randint(1, 30))
        dia_fin = repr(random.randint(1, 31))
        año_ini = '2021'
    else:
        mes_ini = meses[5] #inicio en febrero
        mes_fin = meses[9] #fin en junio
        dia_ini = repr(random.randint(1, 28))
        dia_fin = repr(random.randint(1, 30))
        año_ini = '2022'
    año_fin = '2022'
    #fecha_inicio
    fila.insert(0, año_ini+"-"+mes_ini+"-"+dia_ini)
    #fecha_fin
    fila.insert(1, año_fin+"-"+mes_fin+"-"+dia_fin)
    #tipo_beca
    fila.insert(2, tipoBeca[random.randint(0, len(tipoBeca)-1)])
    #duracion
    fila.insert(3, duracion)
    #cuantia
    fila.insert(4, random.randint(500,2000))
    #estudiante
    fila.insert(5, i)
    #universidad
    fila.insert(6, random.choice(codigos_universidad))
    lista.insert(i, fila)
writer.writerows(lista)
file.close()
prep_csv('estancias.csv')
print("Estancias generadas")


file = open('convalidaciones.csv', 'w', newline='')
lista_convalidaciones = [[]]
asignaturas_origen = {}
asignaturas_destino = {}
notas = {'A+': '10', 'A': '9.8', 'A-': '9.5', 'B+': '9', 'B': '8.5', 'B-': '8', 'C+': '7.5', 'C': '7.3', 'C-': '7', 'D+': '6.5', 'D': '6', 'D-': '5.5', 'E': '5', 'F': '4'}
writer = csv.writer(file, delimiter=';')
for i in range(5000000):
    
    if estancias[repr(i)] == '1' or estancias[repr(i)] == '2':
        minimo = 3
        maximo = 5
    else:
        minimo = 6
        maximo = 10
    asignaturas_origen.update({repr(i) : []})
    asignaturas_destino.update({repr(i) : []})
    for j in range(random.randint(minimo,maximo)):
        fila = []
        #nota_destino
        fila.insert(0,random.choice(list(notas.keys())))
        #nota_origen
        fila.insert(1,notas[fila[0]])
        #fecha
        mes = random.choice(meses)
        if mes == '01' or mes == '03' or mes == '05' or mes == '10' or mes == '12':
            dia = repr(random.randint(1, 31))
        elif mes == '02':
            dia = repr(random.randint(1, 28))
        else:
            dia = repr(random.randint(1, 30))
        fila.insert(2,'2021-'+mes+'-'+dia)
        #estudiante_estancias
        fila.insert(3,lista[i][5])
        #universidad_estancias
        universidad = lista[i][6]
        fila.insert(4,universidad)
        #asignatura_origen: buscamos la asignatura de la universidad origen
        asignatura_origen = random.choice(asignaturas_universidades[universidad])[0]
        while asignatura_origen in asignaturas_origen[repr(i)]:
            asignatura_origen = random.choice(asignaturas_universidades[universidad])[0]
        asignaturas_origen[repr(i)].append(asignatura_origen)
        fila.insert(5, asignatura_origen)
        #asignatura_destino: buscamos la asignatura de una universidad que no sea la origen
        cod = random.choice(codigos_universidad)
        while cod == universidad: #si la universidad es la misma que la origen, buscamos otra
            cod = random.choice(codigos_universidad)
        asignatura_destino = random.choice(asignaturas_universidades[cod])[0]
        while asignatura_destino in asignaturas_destino[repr(i)]:
            asignatura_destino = random.choice(asignaturas_universidades[cod])[0]
        asignaturas_destino[repr(i)].append(asignatura_destino)
        fila.insert(6,random.choice(asignaturas_universidades[cod])[0])
        lista_convalidaciones.append(fila)

writer.writerows(lista_convalidaciones)
file.close()
prep_csv('convalidaciones.csv')
print("Convalidaciones generadas")
